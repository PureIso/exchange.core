import { Action } from "redux";
import { ExchangeUIContainer } from "@interfaces/exchange-ui-container.interface";
import { Price } from "@interfaces/price.interface";
export const CRUDEXCHANGEUICONTAINER = "CRUDEXCHANGEUICONTAINER";

export class CRUDExchangeUIContainer implements Action {
    readonly type = CRUDEXCHANGEUICONTAINER;

    constructor(public payload: ExchangeUIContainer) {
        this.payload = Object.assign({}, payload);
    }

    updatePrices(price: Price) {
        let index = this.payload.prices.findIndex((x: Price) => {
            console.log(x.id);
            console.log(price.id);
            return x.id === price.id;
        });
        console.log(index);
        if (index == -1) {
            this.payload.prices.push(price);
        } else {
            this.payload.prices[index] = price;
        }
        console.log(this.payload.prices);
    }
}

export type Actions = CRUDExchangeUIContainer;
