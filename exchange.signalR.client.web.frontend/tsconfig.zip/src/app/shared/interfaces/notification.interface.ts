export interface Notification {
  id: string;
  content: string;
  style: string;
  dismissed: boolean;
}
