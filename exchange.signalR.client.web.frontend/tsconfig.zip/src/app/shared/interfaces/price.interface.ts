export interface Price {
    id: string;
    price: number;
}
