import { Notification } from "@interfaces/notification.interface";

export interface NotificationContainer {
    notifications: Notification[];
}