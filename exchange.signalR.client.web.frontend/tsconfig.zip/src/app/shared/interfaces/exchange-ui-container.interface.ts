import { Price } from "@interfaces/price.interface";

export interface ExchangeUIContainer {
    prices: Price[];
}