enum MessageType {
  General = 0,
  JsonOutput = 1,
  Error = 2,
}
